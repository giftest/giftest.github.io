# Gift A. Nwatuzie — Professional Portfolio

Professional portfolio for Software Engineering, Machine Learning Engineering, AI, Distributed Systems, Responsible AI, and applied research.

## Live URL
https://giftest.github.io

## Files
- `index.html`
- `css/style.css`
- `js/main.js`
- `assets/images/`
- `assets/resume/`

## GitHub Pages deployment
1. Open repository **Settings**
2. Select **Pages**
3. Under **Build and deployment**, choose **Deploy from a branch**
4. Choose branch **main**
5. Choose folder **/ (root)**
6. Save

## Next stage
Dedicated project case-study pages, architecture diagrams, research visualizations, publication links, professional photo, and final SEO/social preview metadata.
